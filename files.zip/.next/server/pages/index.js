"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 1264:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7753);
/* harmony import */ var _nav__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(422);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_nav__WEBPACK_IMPORTED_MODULE_3__]);
_nav__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nav__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7753:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



const Footer = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
            className: " black text-third m-2 border border-third rounded-xl ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-screen-xl px-4 py-16 mx-auto sm:px-6 lg:px-8",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-second mb-8",
                        children: "Green Apparels"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:flex lg:items-start lg:gap-8",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid grid-cols-2 lg:grid-cols-5 gap-8 mt-8 lg:mt-0 lg:gap-y-16",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-span-2",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "mb-4",
                                                children: "We are a passionate and dedicated team of professionals who are committed to creating high-quality garments that embody both style and comfort."
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/#Contactus",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: " w-[30%] px-6 py-3 mt-1 text-sm font-bold tracking-wide uppercase transition-none rounded-lg border-2 0 sm:mt-0 sm:w-auto sm:flex-shrink-0",
                                                    children: "Contact Us"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-span-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "font-medium text-second",
                                            children: "Company"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                            "aria-label": "Footer Navigation - Company",
                                            className: "mt-6",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                className: "space-y-4 text-sm",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "About"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "Meet the Team"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "Accounts Review"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-span-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "font-medium text-second",
                                            children: "Helpful Links"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                            "aria-label": "Footer Navigation - Company",
                                            className: "mt-6",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                className: "space-y-4 text-sm",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "Contact"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "FAQs"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75",
                                                            children: "Live Chat"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-span-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "font-medium text-second",
                                            children: "Legal"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                            "aria-label": "Footer Navigation - Legal",
                                            className: "mt-6",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                className: "space-y-4 text-sm",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "Accessibility"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "Returns Policy"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "Refund Policy"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "components/common#",
                                                            className: " transition hover:opacity-75 ",
                                                            children: "Hiring Statistics"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "col-span-1 flex justify-start col-span-2 gap-6 lg:col-span-5 ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "/",
                                                rel: "noreferrer",
                                                target: "_blank",
                                                className: " transition hover:opacity-75 dark:text-gray-200",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "sr-only",
                                                        children: "Facebook"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        className: "w-6 h-6",
                                                        fill: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        "aria-hidden": "true",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            "fill-rule": "evenodd",
                                                            d: "M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z",
                                                            clipRule: "evenodd"
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "/",
                                                rel: "noreferrer",
                                                target: "_blank",
                                                className: " transition hover:opacity-75 dark:text-gray-200",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "sr-only",
                                                        children: "Instagram"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        className: "w-6 h-6",
                                                        fill: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        "aria-hidden": "true",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            "fill-rule": "evenodd",
                                                            d: "M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z",
                                                            "clip-rule": "evenodd"
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "/",
                                                rel: "noreferrer",
                                                target: "_blank",
                                                className: " transition hover:opacity-75 dark:text-gray-200",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "sr-only",
                                                        children: "Twitter"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        className: "w-6 h-6",
                                                        fill: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        "aria-hidden": "true",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-8 mt-8 border-t border-gray-100 dark:border-gray-800",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid grid-cols-1 gap-8 lg:grid-cols-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "text-xs text-left dark:text-gray-400",
                                    children: [
                                        "\xa9 2023. ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-xl",
                                            children: "Green Apparenls "
                                        }),
                                        " All rights reserved."
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                    "aria-label": "Footer Navigation - Support",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "flex flex-wrap justify-start gap-4 text-xs lg:justify-end",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "components/common#",
                                                    className: " transition hover:opacity-75 dark:text-gray-400",
                                                    children: "Terms & Conditions"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "components/common#",
                                                    className: " transition hover:opacity-75 dark:text-gray-400",
                                                    children: "Privacy Policy"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "components/common#",
                                                    className: " transition hover:opacity-75 dark:text-gray-400",
                                                    children: "Cookies"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 422:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _sections_exprience__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5850);
/* harmony import */ var _sections_products__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3345);
/* harmony import */ var _sections_affiliations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1898);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sections_exprience__WEBPACK_IMPORTED_MODULE_4__, _sections_products__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_7__]);
([_sections_exprience__WEBPACK_IMPORTED_MODULE_4__, _sections_products__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const variants = {
    open: {
        opacity: 1,
        x: 0
    },
    closed: {
        opacity: 0,
        x: "-100%"
    }
};
const variants_mobile_nav_ul = {
    open: {
        transition: {
            staggerChildren: 0.07,
            delayChildren: 0.2
        }
    },
    closed: {
        transition: {
            staggerChildren: 0.05,
            staggerDirection: -1
        }
    }
};
const variants_mobile_nav_li = {
    open: {
        y: 0,
        opacity: 1,
        transition: {
            y: {
                stiffness: 1000,
                velocity: -100
            }
        }
    },
    closed: {
        y: 50,
        opacity: 0,
        transition: {
            y: {
                stiffness: 1000
            }
        }
    }
};
const Nav = ()=>{
    const [toggle, setToggle] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [nav_color_change, setnav_color_change] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const onScroll = (event)=>{
        const { scrollY  } = window;
        scrollY > 120 ? setnav_color_change(true) : setnav_color_change(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        //add eventlistener to window
        window.addEventListener("scroll", onScroll, {
            passive: true
        });
        // remove event on unmount to prevent a memory leak with the cleanup
        return ()=>{
            window.removeEventListener("scroll", onScroll, {
                passive: true
            });
        };
    }, []);
    const data = [
        {
            title: "Affiliations",
            hash_link: "#Affiliations"
        },
        {
            title: "Products",
            hash_link: "#Products"
        },
        {
            title: "Experience",
            hash_link: "#Exprience"
        },
        {
            title: "About Us",
            hash_link: "#Whychooseus"
        },
        {
            title: "Partnership",
            hash_link: "#Contactus"
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `fixed z-50 w-full bg-[#000000] ${nav_color_change ? "bg-opacity-80" : "bg-opacity-20"} text-second `,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
            className: "container p-0 flex justify-between items-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full py-1 flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/#Whychooseus",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: "/nav/logo.png",
                                alt: "logo",
                                className: "w-16 h-12 md:w-28 md:h-20 object-contain",
                                width: 512,
                                height: 512
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "hidden md:block",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "flex flex-row justify-end items-center space-x-3",
                                children: data.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: item.hash_link,
                                            children: item.title
                                        })
                                    }, index))
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "md:hidden flex justify-end items-center py-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                            src: toggle ? "/nav/close.svg" : "/nav/menu.svg",
                            alt: "menu",
                            className: "w-7 h-7",
                            height: 28,
                            width: 28,
                            onClick: ()=>setToggle(!toggle)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.nav, {
                            animate: toggle ? "open" : "closed",
                            variants: variants,
                            className: ` ${!toggle ? "hidden" : "fixed"}   top-0 right-0 left-0  h-screen bg-[#000000]  `,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-center items-center p-4 py-16",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "border rounded-full border-white p-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: "/nav/close.svg",
                                            alt: "menu",
                                            className: "object-contain",
                                            height: 28,
                                            width: 28,
                                            onClick: ()=>setToggle(!toggle)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.ul, {
                                        variants: variants_mobile_nav_ul,
                                        className: " flex flex-col justify-center items-center space-x-3 text-3xl text-second mt-8 space-y-8",
                                        children: data.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.li, {
                                                variants: variants_mobile_nav_li,
                                                whileHover: {
                                                    scale: 1.1
                                                },
                                                whileTap: {
                                                    scale: 0.95
                                                },
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: item.hash_link,
                                                    onClick: ()=>setToggle(false),
                                                    children: [
                                                        " ",
                                                        item.title
                                                    ]
                                                })
                                            }, index))
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Nav);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9490:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(621);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Sub_Products = ({ item  })=>{
    const [hoverdiv, setHoverDiv] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: " p-2 md:p-4 flex flex-col justify-center items-center text-center ",
        children: [
            !hoverdiv ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("up", "tween", 0.3, 1),
                className: ` h-[200px] md:h-[300px] object-cover rounded-lg  producti`,
                onMouseEnter: ()=>setHoverDiv(true),
                onClick: ()=>setHoverDiv(true),
                initial: {
                    opacity: 1
                },
                exit: {
                    opacity: 0,
                    transition: {
                        duration: 0.2
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    src: item.image,
                    className: "h-[200px] md:h-[300px] rounded-xl object-cover",
                    alt: "alt",
                    height: 300,
                    width: 300
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("up", "tween", 0.3, 1),
                initial: {
                    opacity: 1
                },
                exit: {
                    opacity: 0,
                    transition: {
                        duration: 0.2
                    }
                },
                onMouseOut: ()=>setHoverDiv(false),
                onClick: ()=>setHoverDiv(false),
                className: "h-[200px] md:h-[300px] flex flex-col justify-center items-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "h-[300px] md:max-w-[80%] text-second text-center p-1  md:px-4 md:py-2 overflow-hidden border border-third rounded-xl",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-third text-center text-center",
                            children: item.title
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "md:text-md text-center",
                            children: [
                                item.description_hover,
                                " "
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "text-[#AA8B56] text-center",
                children: item.title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-[#F0EBCE] md:text-md text-center",
                children: item.description
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sub_Products);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4369:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _sections_affiliations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1898);
/* harmony import */ var _sections_clients__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8288);
/* harmony import */ var _sections_client_think_about_us__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3705);
/* harmony import */ var _components_common_Layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1264);
/* harmony import */ var _sections_contactus__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5986);
/* harmony import */ var _sections_csr__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1116);
/* harmony import */ var _sections_factory_image_slide__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9231);
/* harmony import */ var _sections_products__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3345);
/* harmony import */ var _sections_slide__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3113);
/* harmony import */ var _sections_whychooseus__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9233);
/* harmony import */ var _sections_exprience__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5850);
/* harmony import */ var _sections_swot__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7840);
/* harmony import */ var _sections_factory_details__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5437);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_Layout__WEBPACK_IMPORTED_MODULE_6__, _sections_products__WEBPACK_IMPORTED_MODULE_10__, _sections_whychooseus__WEBPACK_IMPORTED_MODULE_12__, _sections_exprience__WEBPACK_IMPORTED_MODULE_13__]);
([_components_common_Layout__WEBPACK_IMPORTED_MODULE_6__, _sections_products__WEBPACK_IMPORTED_MODULE_10__, _sections_whychooseus__WEBPACK_IMPORTED_MODULE_12__, _sections_exprience__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















function Home({ false_data  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_Layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_slide__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                id: "slide"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_whychooseus__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                id: "Whychooseus"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_exprience__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                id: "Exprience"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_products__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                id: "Products"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_factory_details__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_factory_image_slide__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                id: "Factorys"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_csr__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                id: "Csr"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_swot__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                id: "Swot"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_clients__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                id: "Clients"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_contactus__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                id: "Contactus"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections_client_think_about_us__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                id: "Client_think_about_us"
            })
        ]
    });
}
async function getStaticProps() {
    const false_data = {};
    return {
        props: {
            false_data
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1898:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const data = [
    {
        icon: "/factory/logo/logo.svg",
        name: "Garments Name",
        area: "150acr",
        production: "1245+",
        description: "red to other places, and we will give you other bonusesWe will provide the best price for you. from the beat quality we give we will give you a special price compa"
    },
    {
        icon: "/factory/logo/logo.svg",
        name: "Garments Name",
        area: "150acr",
        production: "1245+",
        description: " price for you. from the beat quality we give we will give you a special price compared to  We will provide the bestother places, and we will give you other bonuses"
    },
    {
        icon: "/factory/logo/logo.svg",
        name: "Garments Name",
        description: "he beat quality we give we will give you a special price compared to other places, and we We will provide the best price for you. from twill give you other bonuses"
    },
    {
        icon: "/factory/logo/logo.svg",
        name: "Garments Name",
        area: "150acr",
        production: "1245+",
        description: " you otheWe will provide the best price for you. from the beat quality we give we will give you a special price compared to other places, and we will giver bonuses"
    },
    {
        icon: "/factory/logo/logo.svg",
        name: "Garments Name",
        area: "150acr",
        production: "1245+",
        description: "he beat quality we give we will give you a special price compared to other places, and we We will provide the best price for you. from twill give you other bonuses"
    }
];
const Affiliations = ()=>{
    const [toggleState, setToggleState] = useState(0);
    const toggleTab = (index)=>{
        setToggleState(index);
    };
    return /*#__PURE__*/ _jsx("div", {
        className: "w-full bg-[#001201] py-16 md:py-32 ",
        id: "Affiliations",
        children: /*#__PURE__*/ _jsxs("div", {
            className: "container text-white py-8",
            children: [
                /*#__PURE__*/ _jsx("h1", {
                    className: "text-center text-first py-4",
                    children: "Our Manufactureing Units"
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "my-8 flex flex-col justify-center items-center space-x-8",
                    children: [
                        /*#__PURE__*/ _jsx("div", {
                            className: " px-4 w-full flex justify-center space-x-2 lg:space-x-20",
                            children: data.map((item, index)=>/*#__PURE__*/ _jsx("div", {
                                    className: `${toggleState === index ? "bg-green-900 opacity-80" : ""} p-4 rounded-t-lg `,
                                    children: /*#__PURE__*/ _jsx(Image, {
                                        src: item.icon,
                                        alt: "logo",
                                        className: "w-[64px] h-[64px]",
                                        width: 1,
                                        height: 1,
                                        onClick: ()=>toggleTab(index)
                                    })
                                }, index))
                        }),
                        /*#__PURE__*/ _jsx("div", {
                            className: "w-[90%]",
                            children: data.map((item, index)=>/*#__PURE__*/ _jsx("div", {
                                    className: `${toggleState === index ? " block " : "hidden"} w-full bg-[#151616] opacity-80  p-8   rounded-xl `,
                                    children: /*#__PURE__*/ _jsx("div", {
                                        className: "w-full ",
                                        children: /*#__PURE__*/ _jsxs("div", {
                                            className: "flex justify-start",
                                            children: [
                                                /*#__PURE__*/ _jsx("div", {
                                                    className: "w-full md:w-[30%] flex justify-start items-center",
                                                    children: /*#__PURE__*/ _jsx("div", {
                                                        className: `bg-slate-300 opacity-80  p-4 rounded-t-lg `,
                                                        children: /*#__PURE__*/ _jsx(Image, {
                                                            src: item.icon,
                                                            alt: "logo",
                                                            className: "w-[114px] h-[114px] lg:w-[164px] lg:h-[164px]",
                                                            width: 1,
                                                            height: 1,
                                                            onClick: ()=>toggleTab(index)
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ _jsxs("div", {
                                                    className: "w-[70%] flex flex-col justify-start space-y-2 text-[#177B33] ml-4",
                                                    children: [
                                                        /*#__PURE__*/ _jsx("div", {
                                                            className: "flex justify-start items-center ",
                                                            children: /*#__PURE__*/ _jsx("h2", {
                                                                children: item.name
                                                            })
                                                        }),
                                                        /*#__PURE__*/ _jsxs("div", {
                                                            className: "flex justify-start items-center",
                                                            children: [
                                                                /*#__PURE__*/ _jsx("span", {
                                                                    children: "Area:"
                                                                }),
                                                                /*#__PURE__*/ _jsx("h2", {
                                                                    className: "text-[#F57328]",
                                                                    children: item.area
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ _jsxs("div", {
                                                            className: "flex justify-start items-center",
                                                            children: [
                                                                /*#__PURE__*/ _jsx("span", {
                                                                    children: "Production Capacity :"
                                                                }),
                                                                " ",
                                                                /*#__PURE__*/ _jsx("h2", {
                                                                    className: "text-[#F57328]",
                                                                    children: item.production
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ _jsx("div", {
                                                            className: "flex justify-start items-center",
                                                            children: item.description
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                }, index))
                        })
                    ]
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Affiliations)));


/***/ }),

/***/ 3705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__);





const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1800,
    cssEase: "linear",
    pauseOnHover: false,
    arrows: false,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                initialSlide: 1
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
    ]
};
const reviews = [
    {
        "name": "John Doe",
        "review": "I recently purchased a denim jacket from Green Apparels and I am blown away by the quality. It fits perfectly and the fabric is incredibly durable. I have received so many compliments on it and I am very happy with my purchase."
    },
    {
        "name": "Jane Smith",
        "review": "I work in the hospitality industry and I recently purchased some workwear from Green Apparels. The quality of the clothing is excellent and the turnaround time was quick and efficient. I would definitely recommend this company to anyone in need of workwear."
    },
    {
        "name": "Bob Johnson",
        "review": "I ordered sportswear for my athletic team from Green Apparels and the results were fantastic. The clothing is comfortable, functional, and looks great. I was very impressed with the quality of the products and the service provided by the company."
    },
    {
        "name": "Sarah Davis",
        "review": "I recently placed a large order for outerwear with Green Apparels and I couldn't be happier with the results. The clothing is well-made, stylish, and protects against the elements perfectly. I would definitely use this company for future orders."
    },
    {
        "name": "Tom Wilson",
        "review": "I purchased a suit from Green Apparels for a formal event and I received so many compliments. The fit was perfect, the material was high-quality, and the overall look was sleek and sophisticated. I would definitely recommend this company to anyone in need of a suit."
    }
];
const Client_think_about_us = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full py-8 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container text-white space-y-8 text-white",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-center text-first py-4",
                    children: "Clients Review"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "mb-6 pb-2 md:mb-12 md:pb-0 text-third w-[80%] mx-auto md:w-[65%] text-center",
                    children: "We believe that a satisfied customer is the best form of advertising, and we strive to build long-lasting relationships with our clients. We listen to their feedback and take their opinions into account when making decisions about product design and manufacturing processes."
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                        className: "mb-20 text-gray-700",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: " text-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
                                ...settings,
                                children: reviews.map((person, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "p-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mb-12 md:mb-0 border border-second p-4 rounded-xl",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                    className: "text-xl font-semibold mb-4 text-second",
                                                    children: person.name
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: "mb-4 text-third",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            "aria-hidden": "true",
                                                            focusable: "false",
                                                            "data-prefix": "fas",
                                                            "data-icon": "quote-left",
                                                            className: "w-6 pr-2 inline-block",
                                                            role: "img",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            viewBox: "0 0 512 512",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                fill: "currentColor",
                                                                d: "M464 256h-80v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8c-88.4 0-160 71.6-160 160v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48zm-288 0H96v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8C71.6 32 0 103.6 0 192v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48z"
                                                            })
                                                        }),
                                                        person.review
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                    className: "flex justify-center mb-0",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                "aria-hidden": "true",
                                                                focusable: "false",
                                                                "data-prefix": "fas",
                                                                "data-icon": "star",
                                                                className: "w-4 text-yellow-500",
                                                                role: "img",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                viewBox: "0 0 576 512",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    fill: "currentColor",
                                                                    d: "M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                "aria-hidden": "true",
                                                                focusable: "false",
                                                                "data-prefix": "fas",
                                                                "data-icon": "star",
                                                                className: "w-4 text-yellow-500",
                                                                role: "img",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                viewBox: "0 0 576 512",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    fill: "currentColor",
                                                                    d: "M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                "aria-hidden": "true",
                                                                focusable: "false",
                                                                "data-prefix": "fas",
                                                                "data-icon": "star",
                                                                className: "w-4 text-yellow-500",
                                                                role: "img",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                viewBox: "0 0 576 512",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    fill: "currentColor",
                                                                    d: "M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                "aria-hidden": "true",
                                                                focusable: "false",
                                                                "data-prefix": "fas",
                                                                "data-icon": "star",
                                                                className: "w-4 text-yellow-500",
                                                                role: "img",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                viewBox: "0 0 576 512",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    fill: "currentColor",
                                                                    d: "M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                "aria-hidden": "true",
                                                                focusable: "false",
                                                                "data-prefix": "fas",
                                                                "data-icon": "star-half-alt",
                                                                className: "w-4 text-yellow-500",
                                                                role: "img",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                viewBox: "0 0 536 512",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    fill: "currentColor",
                                                                    d: "M508.55 171.51L362.18 150.2 296.77 17.81C290.89 5.98 279.42 0 267.95 0c-11.4 0-22.79 5.9-28.69 17.81l-65.43 132.38-146.38 21.29c-26.25 3.8-36.77 36.09-17.74 54.59l105.89 103-25.06 145.48C86.98 495.33 103.57 512 122.15 512c4.93 0 10-1.17 14.87-3.75l130.95-68.68 130.94 68.7c4.86 2.55 9.92 3.71 14.83 3.71 18.6 0 35.22-16.61 31.66-37.4l-25.03-145.49 105.91-102.98c19.04-18.5 8.52-50.8-17.73-54.6zm-121.74 123.2l-18.12 17.62 4.28 24.88 19.52 113.45-102.13-53.59-22.38-11.74.03-317.19 51.03 103.29 11.18 22.63 25.01 3.64 114.23 16.63-82.65 80.38z"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }, index))
                            })
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Client_think_about_us);


/***/ }),

/***/ 8288:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__);






const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    autoplay: true,
    speed: 1800,
    autoplaySpeed: 1800,
    cssEase: "linear",
    pauseOnHover: false,
    arrows: false,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 5,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 2,
                initialSlide: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        }
    ]
};
const Clients = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: " py-8 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: " ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-center text-first py-4",
                    children: "Our Clients"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                        ...settings,
                        children: [
                            0,
                            1,
                            2,
                            3,
                            4,
                            5,
                            6,
                            7,
                            8,
                            9,
                            10,
                            11,
                            12,
                            13,
                            14
                        ].map((i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "p-4 mb-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    className: "w-full h-[60px] lg:h-[100px] object-contain shadow-lg",
                                    src: `/clients/${i}.png`,
                                    alt: "alt",
                                    height: 224,
                                    width: 224
                                })
                            }, i))
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Clients);


/***/ }),

/***/ 5986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Contactus = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "text-white py-8 ",
        id: "Contactus",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container mx-auto my-4 px-4 lg:px-20 flex justify-center items-center ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full p-8 my-4 md:px-12 lg:w-9/12 rounded-2xl shadow-2xl",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold uppercase text-second ",
                        children: " Strategic            Partnership  !"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "text-third ",
                        children: "Contact with us"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-1 gap-5 md:grid-cols-2 mt-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "w-full bg-fourth text-third mt-2 p-3 rounded-lg focus:outline-none focus:shadow-outline",
                                type: "text",
                                placeholder: "First Name*"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "w-full bg-fourth text-third mt-2 p-3 rounded-lg focus:outline-none focus:shadow-outline",
                                type: "text",
                                placeholder: "Last Name*"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "w-full bg-fourth text-third mt-2 p-3 rounded-lg focus:outline-none focus:shadow-outline",
                                type: "email",
                                placeholder: "Email*"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "w-full bg-fourth text-third mt-2 p-3 rounded-lg focus:outline-none focus:shadow-outline",
                                type: "number",
                                placeholder: "Phone*"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "my-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                            placeholder: "Message*",
                            className: "w-full h-32 bg-fourth text-third mt-2 p-3 rounded-lg focus:outline-none focus:shadow-outline"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "my-2 w-1/2 lg:w-1/4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "uppercase text-sm font-bold tracking-wide bg-fourth text-third p-3 rounded-lg w-full focus:outline-none focus:shadow-outline",
                            children: "Send Message"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contactus);


/***/ }),

/***/ 1116:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__);






const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    autoplay: true,
    speed: 1800,
    autoplaySpeed: 1800,
    cssEase: "linear",
    pauseOnHover: false,
    arrows: false,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 5,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 2,
                initialSlide: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        }
    ]
};
const Csr = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: " py-8 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: " ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-center text-first pb-4",
                    children: "CSR"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                        ...settings,
                        children: [
                            0,
                            1,
                            2,
                            3,
                            4,
                            5,
                            6,
                            7,
                            8,
                            9,
                            10,
                            11,
                            12
                        ].map((i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "p-4 ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    className: "w-full h-[60px] lg:h-[100px] object-contain shadow-lg",
                                    src: `/csr/${i}.png`,
                                    alt: "alt",
                                    height: 224,
                                    width: 224
                                })
                            }, i))
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Csr);


/***/ }),

/***/ 5850:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(621);
/* harmony import */ var react_countup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(609);
/* harmony import */ var react_countup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_countup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_visibility_sensor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6882);
/* harmony import */ var react_visibility_sensor__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_visibility_sensor__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





// import AnimatedCounter from "../components/animated_number_counter";


const AnimatedCounter = ({ countTo , duration , className  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_visibility_sensor__WEBPACK_IMPORTED_MODULE_6___default()), {
            partialVisibility: true,
            offset: {
                bottom: 0
            },
            children: ({ isVisible  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        height: 100
                    },
                    children: isVisible ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_countup__WEBPACK_IMPORTED_MODULE_5___default()), {
                        className: `${className}`,
                        duration: duration,
                        end: countTo
                    }) : null
                })
        })
    });
};
const data = [
    {
        title: "Recuring clients",
        number: 97
    },
    {
        title: "Clients we Served",
        number: 40
    },
    {
        title: "Smapling Section",
        number: 37
    },
    {
        title: "Imorted Machines",
        number: 52
    }
];
const Exprience = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full bg-[#4E6C50] py-8 md:py-16 lg:py-32",
        id: "Exprience",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                variants: _utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .staggerContainer */ .Jm,
                initial: "hidden",
                whileInView: "show",
                viewport: {
                    once: false,
                    amount: 0.25
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-wrap",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("right", "tween", 0.2, 1),
                            className: " w-full md:w-[37%] flex flex-col justify-center items-center ",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full flex flex-col justify-center items-center text-third",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        children: "8+"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: " border-third drop-shadow-lg shadow-th text-left text-[#0E2007] md:text-5xl md:font-bold px-8 flex",
                                        children: "years of"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-5xl border-b-4 border-second text-main font-bold",
                                        children: "EXPRIENCE"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-third text-center mt-3 mb-12 md:m-8 w-[70%]",
                                        children: " We provide World Class solluton Unmatched to any other company"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full md:w-[63%] ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-2 gap-8",
                                children: data.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("up", "spring", (index + 1) * 0.5, 1),
                                        className: " md:p-6 p-3 bg-[#19320F] border border-gray-500 rounded-lg drop-shadow-xl hover:bg-[#18220F] justify-center items-center text-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "font-bold text-second",
                                                children: item.title
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AnimatedCounter, {
                                                className: "text-4xl font-bold text-third",
                                                countTo: item.number,
                                                duration: (2000 + (index + 1) * 1000) / 1000
                                            })
                                        ]
                                    }, index))
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Exprience);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5437:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ factory_details)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "antd"
const external_antd_namespaceObject = require("antd");
// EXTERNAL MODULE: ./sections/factory_image_slide.js
var factory_image_slide = __webpack_require__(9231);
;// CONCATENATED MODULE: ./components/garments_details.js




const GarmentsDetails = ({ gar , onClose  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full border border-first p-4 rounded-xl bg-main",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " flex justify-end",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/nav/close.svg",
                    alt: "menu",
                    className: "object-contain",
                    height: 28,
                    width: 28,
                    onClick: ()=>onClose(false)
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-center text-first py-2 ",
                children: gar.CompanyName
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "text-center text-third",
                children: gar.Tagline
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container grid grid-cols-1 md:grid-cols-3 gap-8 mt-6 mb-4 md:mb-0",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-center text-second  my-2",
                                children: "Space Allocation"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative overflow-x-auto ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("table", {
                                    className: "w-full text-sm text-left text-gray-500 dark:text-gray-400 flex flex-col justify-center items-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "border border-second rounded-xl p-4",
                                            children: Object.keys(gar.SpaceAllocation).map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                    className: "text-center ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            scope: "row",
                                                            className: "text-third",
                                                            children: item
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-xl text-bold text-orange-600",
                                                            children: gar.SpaceAllocation[item]
                                                        })
                                                    ]
                                                }, index))
                                        })
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-center text-second  my-2",
                                children: "Factsheet"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative overflow-x-auto",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("table", {
                                    className: "w-full text-sm text-left text-gray-500 dark:text-gray-400 flex flex-col justify-center items-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "border border-second rounded-xl p-4",
                                            children: Object.keys(gar.Factsheet).map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                    className: "text-center ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            scope: "row",
                                                            className: "text-third",
                                                            children: item
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                            className: "text-xl text-bold text-orange-600",
                                                            children: gar.Factsheet[item]
                                                        })
                                                    ]
                                                }, index))
                                        })
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-center text-second  my-2",
                                children: "Certification"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative overflow-x-auto",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("table", {
                                    className: "w-full text-sm text-left text-gray-500 dark:text-gray-400 flex flex-col justify-center items-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "border border-second rounded-xl p-4 flex flex-col justify-center items-center",
                                            children: Object.keys(gar.Certification).map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("tr", {
                                                    className: "text-center ",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "text-xl text-bold text-orange-600",
                                                        children: gar.Certification[item]
                                                    })
                                                }, index))
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(factory_image_slide/* default */.Z, {})
        ]
    });
};
/* harmony default export */ const garments_details = (GarmentsDetails);

;// CONCATENATED MODULE: ./sections/factory_details.js





const data = [
    {
        CompanyName: "RONG RUI GARMENT BD LTD",
        Tagline: "A WORLD-CLASS GARMENT FACTORY IN BANGLADESH",
        SpaceAllocation: {
            Cutting: "12,500 SQFT",
            Sewing: "40,000 SQFT",
            Finishing: "14,500 SQFT",
            Dining: "5,000 SQFT",
            WareHouse: "2,500 SQFT",
            FinishedWareHouse: "5,000 SQFT",
            Admin: "500 SQFT"
        },
        Factsheet: {
            YearOfEstablishment: "January 2018",
            Manpower: "Male 710 and Female 868",
            FactoryArea: "80,000 Sq.Ft.",
            SewingLines: "12",
            MonthlyCapacity: "1,20,000 Pcs Jacket and 2,00,000 Pcs Pant",
            YearlyExport: "10 Million US$"
        },
        Certification: [
            "BSCI",
            "SEDEX",
            "WRAP"
        ]
    },
    {
        CompanyName: "Woolen & Wool Limited",
        Tagline: "An Export Oriented Sweater Industry",
        SpaceAllocation: {
            Cutting: "7,000 SQFT",
            Sewing: "20,000 SQFT",
            Finishing: "5,000 SQFT",
            Dining: "2,000 SQFT",
            WareHouse: "2,500 SQFT",
            FinishedWareHouse: "3,000 SQFT",
            Admin: "1,000 SQFT"
        },
        Factsheet: {
            YearOfEstablishment: "2003",
            Manpower: "\xb1 300 Persons",
            FactoryArea: "35,000 ft2 (3,252 m2)",
            SewingLines: "10",
            MonthlyCapacity: "\xb1 4,000 Dozs. per month",
            YearlyExport: "20 Million US$"
        },
        Certification: [
            "OEKO-TEX",
            "BSCI"
        ]
    },
    {
        CompanyName: "Milina Fashion Co.",
        Tagline: "Leading Fashion Manufacturer in Bangladesh",
        SpaceAllocation: {
            Cutting: "5,000 SQFT",
            Sewing: "15,000 SQFT",
            Finishing: "7,500 SQFT",
            Dining: "2,000 SQFT",
            WareHouse: "2,000 SQFT",
            FinishedWareHouse: "3,000 SQFT",
            Admin: "500 SQFT"
        },
        Factsheet: {
            YearOfEstablishment: "2010",
            Manpower: "450 Employees",
            FactoryArea: "40,000 Sq.Ft.",
            SewingLines: "8",
            MonthlyCapacity: "350000 Pcs garments",
            YearlyExport: ""
        },
        Certification: []
    },
    {
        CompanyName: "GEEBEE GARMENTS",
        Tagline: "SINCE1892",
        SpaceAllocation: {
            Cutting: "2000 sq.ft.",
            Sewing: "3000 sq.ft.",
            Finishing: "1000 sq.ft.",
            Dining: "500 sq.ft.",
            WareHouse: "5000 sq.ft.",
            FinishedWareHouse: "3000 sq.ft.",
            Admin: "1000 sq.ft."
        },
        Factsheet: {
            YearOfEstablishment: "1950",
            Manpower: "200",
            FactoryArea: "12000 sq.ft.",
            SewingLines: "20",
            MonthlyCapacity: "50,000 pcs",
            YearlyExport: "2 Million USD"
        },
        Certification: [
            "ISO 9001:2015",
            "OHSAS 18001:2007",
            "SA 8000:2014"
        ]
    },
    {
        CompanyName: "RMM SWEATER DIVISION",
        Tagline: "A conglomerate diversified manufacturing industry in Bangladesh engaged in business of sweater",
        SpaceAllocation: {
            Cutting: "10,000 SQFT",
            Sewing: "20,000 SQFT",
            Finishing: "7,000 SQFT",
            Dining: "2,000 SQFT",
            WareHouse: "6,000 SQFT",
            FinishedWareHouse: "2,000 SQFT",
            Admin: "2,700 SQFT"
        },
        Factsheet: {
            YearOfEstablishment: "2010",
            Manpower: "1000 Members under RMM family (Garments)",
            FactoryArea: "47,700 SQFT",
            SewingLines: "50 Lines",
            MonthlyCapacity: "1,50,000Pcs/Per Month",
            YearlyExport: "us$9.50 million"
        },
        Certification: [
            "OEKO-TEX",
            "BSCI",
            "GOTS",
            "OCS",
            "SEDEX",
            "ACCORD"
        ]
    }
];
const FactoryDetails = ()=>{
    const [toggleState, setToggleState] = (0,external_react_.useState)(0);
    const [open, setOpen] = (0,external_react_.useState)(false);
    const showDrawer = ()=>{
        setOpen(true);
    };
    const onClose = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full bg-[#001201] py-8 md:py-16 lg:py-32 ",
        id: "Affiliations",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-center text-first py-2 ",
                children: "Our Manufactureing Units"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container text-white py-8 ",
                children: data.map((gar, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col justify-center items-center space-y-2 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: " ",
                                onClick: showDrawer,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                    className: "shadow-xl border border-third rounded-xl p-3 my-2 text-second",
                                    children: [
                                        gar.CompanyName,
                                        " "
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_namespaceObject.Drawer, {
                                placement: "left",
                                closable: false,
                                onClose: onClose,
                                open: open,
                                bodyStyle: {
                                    backgroundColor: "#0E2007"
                                },
                                width: "100%",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(garments_details, {
                                        gar: gar,
                                        onClose: onClose
                                    }),
                                    ","
                                ]
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const factory_details = (FactoryDetails);


/***/ }),

/***/ 9231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);







const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1800,
    pauseOnHover: false,
    arrows: false
};
const data = [
    {
        title: "A WORLD-CLASS GARMENT FACTORY IN BANGLADESH",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/factory/factory_hole.png"
    },
    {
        title: "SEWING FLOOR",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/factory/SEWING_FLOOR.jpg"
    },
    {
        title: "CUTTING FLOOR",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/factory/CUTTING_FLOOR.jpg"
    },
    {
        title: "Sewinig Machine",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/factory/Sewinig_Machine.jpg"
    }
];
const Factorys = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full md:py-16 md:py-32",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_4___default()), {
            ...settings,
            children: data.map((factory, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full z-10 relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative w-full rounded-md overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "w-full h-[444px] lg:h-[600px] object-cover",
                                src: factory.image,
                                alt: "alt",
                                height: 1024,
                                width: 1024
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute w-full h-full px-[8%] pt-[16%] top-0 flex flex-col items-left justify-center ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-first mt-32",
                                children: factory.title
                            })
                        })
                    ]
                }, index))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Factorys);


/***/ }),

/***/ 3345:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_sub_products__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9490);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(621);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_sub_products__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
([_components_sub_products__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const data = [
    {
        image: "/products/denims.png",
        title: "Denim",
        description: "Stylish and long-lasting jeans, jackets, and skirts",
        description_hover: "Our company specializes in producing clothing made from denim, a sturdy and durable cotton twill fabric. Known for its classic blue color, denim is a versatile material that can be used to create a range of clothing items, including jeans, jackets, and skirts. Our focus is on producing high-quality denim clothing that is both stylish and long-lasting.",
        link: ""
    },
    {
        image: "/products/outware.jpg",
        title: "Out Ware",
        description: "Protective clothing for outdoor use.",
        description_hover: "Our focus is on producing high-quality outerwear for outdoor use. Our clothing is designed to protect against the elements, such as rain, wind, and cold weather, while also offering comfort and style. " + "Whether you're hiking, camping, or just enjoying the great outdoors, our outerwear will keep you protected and comfortable.",
        link: ""
    },
    {
        image: "/products/sports.jpg",
        title: "Sport Wear",
        description: "Athletic clothing designed with comfort, functionality, and performance in mind",
        description_hover: "Specializes in producing sportswear for individuals engaged in physical activity. Our clothing is designed with comfort, functionality, and performance in mind, to help athletes perform at their best.",
        link: ""
    },
    {
        image: "/products/suits.png",
        title: "Suits",
        description: " Formal attire for men, consisting of a jacket and trousers.",
        description_hover: "We offer a range of suits for men, designed for formal or professional occasions. Our suits are made from high-quality materials and come in a variety of styles and fits to meet the needs and preferences of our customers.",
        link: ""
    },
    {
        image: "/products/military.jpg",
        title: "Uniform",
        description: "Clothing worn by law enforcement personnel such as police, army, and firefighters.",
        description_hover: "We manufacture clothing specifically designed for use by law enforcement personnel such as police, army, and firefighters to serve as a means of identification." + "Clothing worn by members of a specific profession, organization, or group, typically as a means of identification.",
        link: ""
    },
    {
        image: "/products/uniform.png",
        title: "Work Wear",
        description: "Clothing for Hospitality, Healthcare, and Industrial sectors.",
        description_hover: " Our focus is on producing high-quality workwear for Hospitality, Healthcare, and Industrial sectors, ensuring durability and longevity in harsh working environments.",
        link: ""
    }
];
const Products = ()=>{
    const [hoverdiv, setHoverDiv] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full py-8 md:py-16 lg:py-32 ",
        id: "Products",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container space-y-8 ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                variants: _utils_motion__WEBPACK_IMPORTED_MODULE_5__/* .staggerContainer */ .Jm,
                initial: "hidden",
                whileInView: "show",
                viewport: {
                    once: false,
                    amount: 0.25
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_5__/* .fadeIn */ .Ji)("right", "tween", 0.2, 1),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-center text-first py-4",
                            children: "Our Products"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap ",
                        children: data.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_5__/* .fadeIn */ .Ji)("up", "spring", index * 0.5, 1),
                                className: "w-1/2 lg:w-1/3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_sub_products__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    item: item
                                })
                            }, index))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Products);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3113:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);




// import Carousel from "react-multi-carousel";
// import "react-multi-carousel/lib/styles.css";



const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1800,
    pauseOnHover: false,
    arrows: false
};
const data = [
    {
        title: "Denim",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/denims.jpg"
    },
    {
        title: "Jacket",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/jacket.jpg"
    },
    {
        title: "Out Ware",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/outware.jpg"
    },
    {
        title: "Sport Wear",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/sportwear.jpg"
    },
    {
        title: "Suits",
        description: "Short description of the product goes here",
        link: "",
        image: "/slide/suits.jpg"
    }
];
const Slide = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_4___default()), {
            ...settings,
            children: data.map((slide, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full z-10 relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative w-full rounded-md overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "w-full h-[500px] md:h-[555px] lg:h-[755px] object-cover",
                                src: slide.image,
                                alt: "alt",
                                height: 1023,
                                width: 1024
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "absolute w-full h-full p-[16%] top-0 flex flex-col items-left justify-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-third mt-32",
                                    children: slide.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: " text-second",
                                    children: slide.description
                                })
                            ]
                        })
                    ]
                }, index))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Slide);


/***/ }),

/***/ 7840:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Swot = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full py-8 md:py-16 flex flex-col items-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " container text-first flex flex-col justify-center items-center rounded-xl p-4 ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        className: "text-center text-first ",
                        children: [
                            "Sollution Provided By",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-center text-first py-4 border-b-2 border-second mb-4",
                        children: "GREEN APPARELS"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                src: "/swot/swot.svg",
                alt: "logo",
                className: "w-full md:w-[70%] ",
                width: 1,
                height: 1,
                onClick: ()=>toggleTab(index)
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Swot);


/***/ }),

/***/ 9233:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(621);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const data = [
    {
        icon: "/whychooseus/1.svg",
        title: "Trusted PartnerShip",
        description: "we favor long term strategic partnerships with our clients which is reflected in the time we have enjoyed relationships with some of the world’s major brands"
    },
    {
        icon: "/whychooseus/2.svg",
        title: "Integrity",
        description: "we believe firmly that our integrity and professionalism coupled with our multi category offer sets us apart."
    },
    {
        icon: "/whychooseus/3.svg",
        title: "stability",
        description: "we seek to re-invest to secure a long and prosperous future for about organization and ensure a stable and reliable supply  chain for our clients"
    },
    {
        icon: "/whychooseus/4.svg",
        title: "Greater Flexibility",
        description: "To pioneer as the ever growing vendor of choice and recognized organization for quality and innovative supply and services across all the continents."
    }
];
const Whychooseus = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full py-8 md:py-16 lg:py-32",
        id: "Whychooseus",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("up", "tween", 0.3, 1),
                initial: "hidden",
                whileInView: "show",
                viewport: {
                    once: false,
                    amount: 0.1
                },
                className: ` mx-auto flex flex-col`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-center text-first py-4",
                        children: "Why Choose Us"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: "text-sm md:text-lg lg:text-xl md:w-[70%] mx-auto text-center text-second ",
                        children: "In short, our clients satisfaction and belief in our products is the foundation of our business, and we are committed to making it a priority in everything we do."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "md:p-8 flex flex-wrap justify-center",
                        children: data.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-1/2 py-6 flex flex-col items-center space-y-4 ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        src: item.icon,
                                        alt: "logo",
                                        className: "w-[48px] h-[48px]",
                                        width: 1,
                                        height: 1
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-center text-second",
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "w-[65%] text-center text-third",
                                        children: item.description
                                    })
                                ]
                            }, index))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Whychooseus);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 621:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ji": () => (/* binding */ fadeIn),
/* harmony export */   "Jm": () => (/* binding */ staggerContainer)
/* harmony export */ });
/* unused harmony exports navVariants, slideIn, textVariant, textContainer, textVariant2, planetVariants, zoomIn, footerVariants */
const navVariants = {
    hidden: {
        opacity: 0,
        y: -50,
        transition: {
            type: "spring",
            stiffness: 300,
            damping: 140
        }
    },
    show: {
        opacity: 1,
        y: 0,
        transition: {
            type: "spring",
            stiffness: 80,
            delay: 1
        }
    }
};
const slideIn = (direction, type, delay, duration)=>({
        hidden: {
            x: direction === "left" ? "-100%" : direction === "right" ? "100%" : 0,
            y: direction === "up" ? "100%" : direction === "down" ? "100%" : 0
        },
        show: {
            x: 0,
            y: 0,
            transition: {
                type,
                delay,
                duration,
                ease: "easeOut"
            }
        }
    });
const staggerContainer = (staggerChildren, delayChildren)=>({
        hidden: {},
        show: {
            transition: {
                staggerChildren,
                delayChildren
            }
        }
    });
const textVariant = (delay)=>({
        hidden: {
            y: 50,
            opacity: 0
        },
        show: {
            y: 0,
            opacity: 1,
            transition: {
                type: "spring",
                duration: 1.25,
                delay
            }
        }
    });
const textContainer = {
    hidden: {
        opacity: 0
    },
    show: (i = 1)=>({
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
                delayChildren: i * 0.1
            }
        })
};
const textVariant2 = {
    hidden: {
        opacity: 0,
        y: 20
    },
    show: {
        opacity: 1,
        y: 0,
        transition: {
            type: "tween",
            ease: "easeIn"
        }
    }
};
const fadeIn = (direction, type, delay, duration)=>({
        hidden: {
            x: direction === "left" ? 100 : direction === "right" ? -100 : 0,
            y: direction === "up" ? 100 : direction === "down" ? -100 : 0,
            opacity: 0
        },
        show: {
            x: 0,
            y: 0,
            opacity: 1,
            transition: {
                type,
                delay,
                duration,
                ease: "easeOut"
            }
        }
    });
const planetVariants = (direction)=>({
        hidden: {
            x: direction === "left" ? "-100%" : "100%",
            rotate: 120
        },
        show: {
            x: 0,
            rotate: 0,
            transition: {
                type: "spring",
                duration: 1.8,
                delay: 0.5
            }
        }
    });
const zoomIn = (delay, duration)=>({
        hidden: {
            scale: 0,
            opacity: 0
        },
        show: {
            scale: 1,
            opacity: 1,
            transition: {
                type: "tween",
                delay,
                duration,
                ease: "easeOut"
            }
        }
    });
const footerVariants = {
    hidden: {
        opacity: 0,
        y: 50,
        transition: {
            type: "spring",
            stiffness: 300,
            damping: 140
        }
    },
    show: {
        opacity: 1,
        y: 0,
        transition: {
            type: "spring",
            stiffness: 80,
            delay: 0.5
        }
    }
};


/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 609:
/***/ ((module) => {

module.exports = require("react-countup");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 6882:
/***/ ((module) => {

module.exports = require("react-visibility-sensor");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6197:
/***/ ((module) => {

module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,999], () => (__webpack_exec__(4369)));
module.exports = __webpack_exports__;

})();